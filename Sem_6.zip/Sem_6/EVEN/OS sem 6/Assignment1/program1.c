#include<stdio.h>
#include<stdlib.h>
 
typedef struct node
{
 float at,bt,wt,st,ft,tat;
 int pid;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void Insert(PPNODE Head,float arrival_time,float burst_time,int pid)
{
 PNODE newn = (PNODE)malloc(sizeof(NODE));

 newn->at=arrival_time;
 newn->bt=burst_time;
 newn->pid=pid;
 newn->next=NULL;

 if((*Head)==NULL)
 {
  (*Head)=newn;
 }
 else
 {
  PNODE temp=(*Head);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
}
void Display(PNODE Head,float fResult1,float fResult2)
{
 PNODE temp=Head;
 printf("\nProcess  Arrival Time  Burst Time  Start Time    Wait Time    Final Time    Turn Around Time");
 while(temp!=NULL)
 {
   printf("\n");
   printf("\nP%d\t %.1f\t\t %.1f\t\t %.1f\t\t%.1f\t\t%.1f\t\t%.1f\n",temp->pid,temp->at,temp->bt,temp->st,temp->wt,temp->ft,temp->tat);

   temp=temp->next;
 }
 printf("\n");
 printf("Average Wait time is :%.1f\n",fResult1);
 printf("Average Turn Around time is :%.2f\n ",fResult2);

}

void gannt_Chart(PNODE Head,int size)
{
 PNODE temp=Head->next;
 PNODE t=Head;
 int i;

 printf("\n------------------GANTT CHART--------------------\n\n");
 printf("|--P[%d]--|",t->pid);
 while(temp!=NULL)
 {
  if((temp->ft)-(temp->bt)!=t->ft)
  {
   printf("|CPU-IDLE|--P[%d]--",temp->pid);
  }
  else
  {
   printf("|--P[%d]--",temp->pid);
  }
  t=temp;
  temp=temp->next;
 }
 printf("|\n");
 temp=Head->next;
 t=Head;

 printf("%.1f     %.1f ",t->at,t->ft);
 while(temp!=NULL)
 {
  if((temp->ft)-(temp->bt)!=t->ft)
  {
   printf("      %3.2f      %3.2f ",(temp->ft)-(temp->bt),temp->ft);
  }
  else
  {
   printf("      %3.2f",temp->ft);
  }
  t=temp;
  temp=temp->next;
 }
 printf("\n");
 printf("\n-------------------------------------------------------\n");

}
void Calculate(PNODE Head,int size)
{
  float AvgWT=0.0,AvgTAT=0.0,iCnt=1.000000;
  PNODE temp=Head;

  temp->st=temp->at;
  temp->wt=((temp->st)-(temp->at));
  AvgWT+=temp->wt;
  temp->ft=((temp->st)+(temp->bt));
  float f=temp->ft;
  temp->tat=((temp->ft)-(temp->at));
  AvgTAT+=temp->tat;

  float g=temp->at;
  float m=0.0;

  float s=0.0;
  
  temp=temp->next;

  while(temp!=NULL)
  {
   m=temp->at;
     
   if(m!=iCnt)
   {
    temp->st=temp->at;
    s=temp->at;
    temp->at=iCnt;
    temp->at=s;
    temp->wt=((temp->st)-(temp->at));
    AvgWT+=temp->wt;
    temp->ft=((temp->st)+(temp->bt));
    f=temp->ft;
    temp->tat=((temp->ft)-(temp->at));
    AvgTAT+=temp->tat; 
   } 
   else
   {
    temp->st=f;
    temp->wt=((temp->st)-(temp->at));
    AvgWT+=temp->wt;
    temp->ft=((temp->st)+(temp->bt));
    f=temp->ft;
    temp->tat=((temp->ft)-(temp->at));
    AvgTAT+=temp->tat;
   }
   
   iCnt++;
   temp=temp->next;
  }
  Display(Head,AvgWT/size,AvgTAT/size);
}

void Calculate1(PNODE Head,int size)
{
  float AvgWT=0.0,AvgTAT=0.0,iCnt=1.000000;
  PNODE temp=Head;

  temp->st=temp->at;
  temp->wt=((temp->st)-(temp->at));
  AvgWT+=temp->wt;
  temp->ft=((temp->st)+(temp->bt));
  float f=temp->ft;
  temp->tat=((temp->ft)-(temp->at));
  AvgTAT+=temp->tat;

  temp=temp->next;

  while(temp!=NULL)
  {
    temp->st=f;
    temp->wt=((temp->st)-(temp->at));
    AvgWT+=temp->wt;
    temp->ft=((temp->st)+(temp->bt));
    f=temp->ft;
    temp->tat=((temp->ft)-(temp->at));
    AvgTAT+=temp->tat;

   temp=temp->next;
  }
  Display(Head,AvgWT/size,AvgTAT/size);
}

void Sort(PNODE Head)
{
 PNODE temp=Head;
 PNODE temp1=NULL;
 float No1=0.0,No2=0.0;
 int No;

 while(temp->next!=NULL)
 {
   temp1=temp->next;
   
   while(temp1!=NULL)
   {
    if(temp->at > temp1->at)
    {
      No1=temp->at;
      temp->at=temp1->at;
      temp1->at=No1;
      
      No2=temp->bt;
      temp->bt=temp1->bt;
      temp1->bt=No2;

      No=temp->pid;
      temp->pid=temp1->pid;
      temp1->pid=No;
    }
    temp1=temp1->next;
   }
   temp=temp->next;
 }
}

void Sort1(PNODE Head)
{
 PNODE temp=Head;
 PNODE temp1=NULL;
 float No1=0.0,No2=0.0;
 int No;

 while(temp->next!=NULL)
 {
   temp1=temp->next;

   while(temp1!=NULL)
   {
    if(temp->bt > temp1->bt)
    {
      No1=temp->at;
      temp->at=temp1->at;
      temp1->at=No1;

      No2=temp->bt;
      temp->bt=temp1->bt;
      temp1->bt=No2;

      No=temp->pid;
      temp->pid=temp1->pid;
      temp1->pid=No;
    }
    temp1=temp1->next;
   }
   temp=temp->next;
 }
}

int main()
{
 PNODE first=NULL;
 int size=0,i=1;
 float arrival_time=0.0,burst_time=0.0;
 float iNo=0;

 printf("How Many Process u want to enter : ");
 scanf("%d",&size);
 
 for(i=1;i<=size;i++)
 {
  printf("Enter the details of %d process :\n ",i);
  printf("\n");
  printf("Enter arrival time of %d process : ",i);
  scanf("%f",&arrival_time);
  printf("Enter burst time of %d process : ",i);
  scanf("%f",&burst_time);
  printf("___________________________________\n");
  
  iNo+=arrival_time; 
  Insert(&first,arrival_time,burst_time,i);
 }
 
 if(iNo==0)
 {
  Sort(first);
  Calculate1(first,size);
 }
 else
 {
  Sort(first);
  Calculate(first,size);
 }
 gannt_Chart(first,size);
 return 0;
}
