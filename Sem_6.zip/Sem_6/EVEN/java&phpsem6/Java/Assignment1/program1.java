import java.io.*;
import java.util.*;
class program1
{
 public static void main(String args[])throws IOException
 {
   InputStreamReader iobj = new InputStreamReader(System.in);
   BufferedReader bobj = new BufferedReader(iobj);
   
   int size=0;
   System.out.println("How Many details u want to enter : ");
   size=Integer.parseInt(bobj.readLine());

   String Name;
   long Mobile=0;
   
   Hashtable<String,Long> ht = new Hashtable<String,Long>();
   Person pobj[] = new Person[size];

   for(int i=0;i<pobj.length;i++)
   {
    System.out.println("Enter the name of "+(i+1)+" person");
    Name=bobj.readLine();
    if(ht.containsKey(Name))
    {
     System.out.println("Do not Allowed Duplicate Please Enter Another Name : ");
     Name=bobj.readLine();
    }
    System.out.println("Enter the Mobile Number of "+(i+1)+" person");
    Mobile=Long.parseLong(bobj.readLine());

    pobj[i]=new Person(Name,Mobile);
    ht.put(pobj[i].getName(),pobj[i].getMobile());
   }
   
   Iterator<Map.Entry<String,Long>> it = ht.entrySet().iterator();

   Map.Entry<String,Long> entry=null;

   System.out.println("________________________________________________________");

   while(it.hasNext())
   {
    entry=it.next();
    System.out.println(entry.getKey()+"->"+entry.getValue());
   }
   
   System.out.println("________________________________________________________");

   System.out.println("Enter the Name that that u want to search : ");
   String str=bobj.readLine();

   Iterator<Map.Entry<String,Long>> i = ht.entrySet().iterator();

   Map.Entry<String,Long> e = null;

   if(ht.containsKey(str))
   {
    while(i.hasNext())
    {
     e=i.next();
     String s=e.getKey();
     if(s.equals(str))
     {
       System.out.println("________________________________________________________");
       System.out.println(e.getKey()+"->"+e.getValue());
       System.out.println("________________________________________________________");
       break;
     }
    }
   }
   else
   {
     System.out.println("Person Name is Not there");
   }
 }
}
class Person
{
 private String Name;
 private long Mobile;

 public Person(String Name,long Mobile)
 {
  this.Name=Name;
  this.Mobile=Mobile;
 }
 
 public String getName()
 {
  return this.Name;
 }

 public long getMobile()
 {
  return this.Mobile;
 }
}
