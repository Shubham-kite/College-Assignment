import java.util.*;
import java.io.*;
class List{

public static void main(String args[])
{
    Scanner input = new Scanner(System.in);
    LinkedList l1 = new LinkedList();
    LinkedList l2 = new LinkedList();
    LinkedList l3 = new LinkedList();	//union 
    LinkedList l4 = new LinkedList();	//intersection
    int ch;
    System.out.print("Enter Number of elements in list 1 :");
    int size1 = input.nextInt();
    for(int i=0;i<size1;i++)
    {
	System.out.println("Enter Element :"+(i+1));
	int ele = input.nextInt();
	if(!l1.contains(ele));
	    l1.add(ele);

    }

    System.out.println("List L1 contains :"+l1);

    System.out.print("Enter Number of elements in list 2 :");
    int size2 = input.nextInt();
    for(int i=0;i<size2;i++)
    {
	System.out.println("Enter Element :"+(i+1));
	int element = input.nextInt();
	if(!l2.contains(element));
	    l2.add(element);

    }
    System.out.println("List L1 contains :"+l2);

    do{
	System.out.print("Menu \n1.Union \n2.Instersection \n0.Exit\nEnter Choice : ");
	 ch = input.nextInt();
	switch(ch)
	{
	     
	      case 1:
		      {
			    // for union of linkedlist
			    for(int i=0;i<l1.size();i++)
			    {
				l3.add(l1.get(i));
			    }
			    
			   // System.out.print(l3);
			    for(int i=0;i<l2.size();i++)
			    {
				// for avoiding duplication
				if(!l1.contains(l2.get(i)))
				    {
				        l3.add(l2.get(i));
				    }
			    }
			     System.out.println("Union is :"+l3);

		      }
			      break;
	      case 2:
		      {
			    for(int i=0;i<l1.size();i++)
			      {
				  l4.add(l1.get(i));
				  l4.retainAll(l2);
			      }
			    System.out.println("Intersection is :"+l4);
		      }
			      break;


	}

}while(ch!=0);




}
}
