drop table employee;
create table employee(empid int primary key, empname varchar(20), salary float);
