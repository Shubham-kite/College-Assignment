drop table attendance;
create table attendance(roll int primary key,name varchar(20),class varchar(5),subject varchar(20),attendance int);
