import java.util.*;
import java.io.*;
import java.sql.*;

public class Attendance
{
  public static void main(String argv[]) throws SQLException
  {
     Connection conn = null;
     Statement state = null;
     ResultSet rs    = null;
     PreparedStatement insert = null,prepare = null;
//creating object for input
    Scanner input = new Scanner(System.in);
    
      try
	{	
	  
	  //establishing connection to the database
	  Class.forName("org.postgresql.Driver");
	  conn = DriverManager.getConnection("jdbc:postgresql://192.168.16.1/ty8804","ty8804","");
	  insert = conn.prepareStatement("insert into attendance values(?,?,?,?,?)");
    
      if(conn==null)
      {
	  System.out.println("Connection failed");
      }
      else
      {
	  System.out.println("Connection sucessfull");
      }


	}catch(Exception e){System.out.print(e);}
      int ch;
do
{
System.out.print("\n1 Insert \n2 Display Attendance Marks \n0 Exit\n"); 
System.out.println("Enter your Choice :");
ch = input.nextInt();

  switch(ch)
    {
	  //for insert data
	case 1:
		{
		    System.out.print("\nEnter Roll No :");
		    int rollno = input.nextInt();
		    System.out.print("\nEnter name :");
		    String name = input.next();
		    System.out.print("\nEnter Class  :");
		    String classname = input.next();
		    System.out.print("\nEnter Subject Name  :");
		    String subject = input.next();
		    System.out.print("\nEnter Attendance  :");
		    int attendance = input.nextInt();
		    insert.setInt(1,rollno);
		    insert.setString(2,name);
		    insert.setString(3,classname);
		    insert.setString(4,subject);
		    insert.setInt(5,attendance);
		    insert.executeUpdate();

		    
		}
		    break;
	case 2:
	      {
		    int mark;
		    String name;
		   //rs = state.executeQuery("select name,attended ,total_attendance from attendance");
		    prepare = conn.prepareStatement("select name,attendance from attendance");
		    rs = prepare.executeQuery();
		    
		    while(rs.next())
		    {
			 mark  = rs.getInt(2);
			 name  = rs.getString(1);
			if(mark<10)
			    {
				System.out.print(name + " Mark is "+ 1);  
			    }
			  
			else if (mark>11 && mark<20){	  System.out.println(name + " Mark is "+ 2);}
		
			else if (mark>21 && mark<30){  System.out.println(name + " Mark is "+ 3);}
			 
			else if (mark>31 && mark<40){ System.out.println(name + " Mark is "+ 4);}
			 
			else if (mark>41 && mark<50){ System.out.println(name + " Mark is "+ 5);}
			
			else if (mark>51 && mark<60){ System.out.println(name + " Mark is "+ 6);}
			 
			else if (mark>41 && mark<70){ System.out.println(name + " Mark is "+ 7);}
			
			else if (mark>41 && mark<80){System.out.println(name + " Mark is "+ 8);}
			  
			else if (mark>81 && mark<90){System.out.println(name + " Mark is "+ 9);}
			else
			  System.out.println(name + " Mark is "+ 10);
		    }
		  
	      }
	      break;
								
    }



}while(ch!=0);

  }


}
