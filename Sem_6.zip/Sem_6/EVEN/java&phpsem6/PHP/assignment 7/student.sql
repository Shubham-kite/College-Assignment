drop table stud_comp;
drop table competition;
drop table student;

create table student(stud_id int not null Primary key, name varchar(20) not null, class varchar(10));
create table competition(c_no int not null Primary key,c_name varchar(20),c_type varchar(10));
create table stud_comp(stud_id int not null references student(stud_id) on delete cascade, c_no int not null references competition(c_no) on delete cascade);


insert into student values(0001,'abc','fy');
insert into student values(0002,'bcd','sy');
insert into student values(0003,'cde','ty');

insert into competition values(011,'comp33','games');
insert into competition values(022,'comp22','coding');
insert into competition values(033,'comp11','cricket');


insert into stud_comp values(0001,022);
insert into stud_comp values(0002,011);
insert into stud_comp values(0003,033);




