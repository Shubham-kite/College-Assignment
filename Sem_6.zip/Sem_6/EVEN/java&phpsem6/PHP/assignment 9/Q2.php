<?php

	date_default_timezone_set("Asia/Calcutta");
	$dir_name=readLine("Enter directory name: ");
	$file_exit=readLine("Enter file extension: ");

	$dir=opendir($dir_name);
	echo "\n\nFiles:\n";

	while(($file=readdir($dir))!=false)
	{
		if(strpos($file,$file_exit)!=false)
		{
			echo "\n".$file."\n";
			$filesizebytes=filesize("$dir_name/$file");
			echo "\nSize:".$filesizebytes."\n";
			echo $file." last access date:".date("F d Y H:i:s.",fileatime("$dir_name/$file"));
			echo "\n-------------------------------------------------------------";
		}
	}
	closedir($dir);
?>
