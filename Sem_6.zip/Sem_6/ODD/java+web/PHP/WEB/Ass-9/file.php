<html>
<head>
<title>File</title>
</head>
<body>
<table border="1">
<tr>
<th>RollNO</th>
<th>Name</th>
<th>Maths</th>
<th>Electronic</th>i
<th>Computer</th>
<th>Percentage</th>
</tr>
<?php
$fw=fopen("file.dat","r");

while(!feof($fw))
{
	$output=fgets($fw);
	$string=explode(" ",$output);
	$percent=$string[2]+$string[3]+$string[4];
	$percent=round($percent/3,2);

	echo 
	"<tr>
	<th>".$string[0]."</th>
	<th>".$string[1]."</th>
	<th>".$string[2]."</th>
	<th>".$string[3]."</th>
	<th>".$string[4]."</th>
	<th>".$percent."%</th>
	</tr>
	";
}
$fclose($fw)

?>
</table>
</body>
</head>
