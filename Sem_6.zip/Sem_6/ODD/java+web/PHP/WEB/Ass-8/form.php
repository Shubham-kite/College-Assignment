<html>
<head>
	<title>Class data</title>
</head>
<body>
<form onsubmit="return check();" style="border:solid red 2px;" method="post">
Book Name<input type="text" name="book_name" required/>
<br><br>Book Quantity<input type="tel" name="book_quantity"  id="quantity" required/>
<br><br>Book Price<input type="tel" name="book_price"  required/>
<br><br>Book Stock<input type="tel" name="book_stock" id="stock" required/>
<br><br><br><br><center><input type="submit" name="submit" value="submit"/></center>
</form>
	<span id="error" style="color:red;font-size:14px;"></span>
<?php
	if(isset($_POST['submit']))
	{
		class book
		{
		var $book_name;
		var $book_quantity;
		var $book_price;
		var $book_stock;
		
		function display()
		{
			echo '<table>
			<tr>
			<th>Book Name</th>
			<th>Quantity</th>
			<th>price</th>
			<th>stock</th>
			</tr>';
			
			echo'<tr>
			<th>'.$_POST['book_name'].'</th>
			<th>'.$_POST['book_quantity'].'</th>
			<th>'.$_POST['book_price'].'</th>
			<th>'.$_POST['book_stock'].'</th>
			</tr></table>';
			
		}
		function __construct()
		{
			$this->book_name=$_POST['book_name'];
			$this->book_quantity=$_POST['book_quantity'];
			$this->book_price=$_POST['book_price'];
			$this->book_stock=$_POST['book_stock'];
			$this->display();
		}
		
		}
		$book=new book();		
	}


?>

<script>
function check()
{
if(parseInt(document.getElementById("stock").value)<parseInt(document.getElementById("quantity").value))
{	
	document.getElementById("error").innerHTML="Stock Would not be less then Quanity";
	return false;
}
return true;
}
</script>
</body>
</html>
