drop table book;
create table book(book_name varchar(20) primary key,book_author varchar(20),book_category varchar(20),book_price int);

insert into book values('let us c','myself','programming',0);
insert into book values('let c','myself','programming',0);
insert into book values(' us c','myself','literature',0);
insert into book values(' c','myself','novel',0);

