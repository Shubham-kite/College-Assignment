<html>
<head>
	<title>MOvie</title>
</head>
<body>
	<form action="output.php" type="post">
		Get Movie name by actor<input type="radio" class='radio' name="radio" value="movie_name"/required><br>
		Update Release Date<input type="radio" class='radio' name="radio" value="update" >
	<br>	<input type="submit" name="Submit" required/>
	</form>

</body>
</html>

