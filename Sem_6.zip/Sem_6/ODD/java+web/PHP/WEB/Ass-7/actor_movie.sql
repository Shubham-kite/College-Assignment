DROP TABLE MOVIE cascade;
DROP TABLE ACTOR cascade;
DROP TABLE movie_ACTOR cascade;

CREATE TABLE MOVIE(MOVIE_NO INT PRIMARY KEY,MOVIE_NAME VARCHAR(20) NOT NULL,RELEASE_YEAR DATE NOT NULL);
CREATE TABLE ACTOR(ACTOR_NO INT PRIMARY KEY,ACTOR_NAME VARCHAR(20) NOT NULL);

create table movie_actor( MOVIE_NO int references movie (MOVIE_NO) ,actor_no int references actor(actor_no));

insert into movie values(1,'ddlg','2021-2-12');
insert into movie values(2,'dg','2021-3-12');
insert into movie values(3,'lg','2021-4-12');
insert into movie values(4,'dg','2021-5-12');
insert into movie values(5,'dlg','2021-6-12');

insert into actor values(11,'srk');
insert into actor values(14,'rk');
insert into actor values(13,'kk');
insert into actor values(12,'sk');

insert into movie_actor values(1,11);
insert into movie_actor values(2,11);
insert into movie_actor values(3,12);
insert into movie_actor values(4,13);




