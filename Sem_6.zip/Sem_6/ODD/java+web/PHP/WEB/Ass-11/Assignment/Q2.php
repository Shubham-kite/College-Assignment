<?php

//echo $rno."<br>".$name."<br>".$per."<br>".$dob."<br>".$mail;
$conn = pg_connect("host=192.168.16.1 dbname=ty8807 user=ty8807 password=");
if(!$conn)
{
    echo "Error during connection";
}

//if (isset($_POST['submit'])){
$rno=$_POST['rno'];
$name1=$_POST['name1'];
$per=$_POST['per'];
$dob=$_POST['dob'];
$mail=$_POST['mail'];

$result1 = pg_query("insert into students_new values($rno,'$name1',$per,'$dob','$mail');");

 if(!$result1){
     echo "An error occured\n";
	      exit;
	 }
 else
	{
      echo "Record inserted successfully!";
	}


?>
