import java.util.Iterator;
import java.util.LinkedList;

class Q1
{
  public static void main(String args[])
 {
  LinkedList<String>lobj = new LinkedList<String>();
  
  lobj.add("Data Analysis");
  lobj.add("java");
  lobj.add("php");
  lobj.add("TCS");
  lobj.add("OS");

  Iterator iobj = lobj.iterator();
  while(iobj.hasNext())
  {
   System.out.println(iobj.next());
  }
 }
}
