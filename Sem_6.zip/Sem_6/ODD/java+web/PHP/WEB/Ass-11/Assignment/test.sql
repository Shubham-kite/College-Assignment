drop table students_new;
create table students_new(rno int primary key, name1 text, per int, dob text, mail varchar(20));
