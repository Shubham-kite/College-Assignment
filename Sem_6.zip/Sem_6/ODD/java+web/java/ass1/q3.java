import java.util.*;
import static java.lang.System.out;
class q3
{
  public static void main (String[]args)
  {
    Set < String > set = new HashSet < String > ();
    Scanner sc = new Scanner (System.in);
      out.println ("Enter number of entry::");
    int n = sc.nextInt ();
    String str;
    int choice = 0;
      out.println ("Enter flavor name");
    while (n-- > 0)
      {
	str = sc.next ();
	//con = sc.nextInt ();
	set.add (str);
      }
    //int con;
//sc.next();
    do
      {
	out.println ("1)Add flavor 2)Search flavor 3)Move for next task");
	choice = sc.nextInt ();
	switch (choice)
	  {
	  case 1:
	    {
	      out.println ("Enter flavor name to add:");
	      str = sc.next ();
	      //con = sc.nextInt ();
	      set.add (str);
	    }
	    break;
	  case 2:
	    {
//out.println(set);
	      out.println ("Enter flavor name to search");
	      str = sc.next ();
	      if (set.contains (str))
		{
		  out.
		    println
		    ("You are lucky this is exitst to eat for you...");
		}
	      else
		out.println ("Oh no, Oh no, Oh no, no no no no no ....");
	      //out.println (set);
	    }
	    break;
	  case 3:
	    choice = 10;
	  }
      }
    while (choice < 3 && choice > 0);
    List < String > stringList = new ArrayList < String > (set);
    out.println ("This is flavor list");
    out.println (stringList);
    //sorting set storing in stringList
    try
    {
      Collections.sort (stringList);
    }
    catch (Exception e)
    {
      out.println (e.getMessage ());
    }
    out.println ("This is sorted list");
    out.println (stringList);
    set = new HashSet (stringList);
    out.println ("This is sorted flavors" + set);
    Hashtable < String, Integer > hashtable =
      new Hashtable < String, Integer > ();
  for (String str1:set)
      {
	out.print ("Enter the price for this flavour " + str1 + "=>");
	int tempvalue = -1;
	while (tempvalue < 0)
	  {
	    tempvalue = sc.nextInt ();
	  }
	hashtable.put (str1, tempvalue);
      }
    out.println (hashtable);
  }
}
