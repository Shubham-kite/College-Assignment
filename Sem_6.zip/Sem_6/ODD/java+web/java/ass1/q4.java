import java.util.*;
import static java.lang.System.out;
import java.io.*;
class Student
{
  int r, age;
  String name;
    Student (int r, int age, String name)
  {
    this.r = r;
    this.name = name;
    this.age = age;
  }

}
class sortByNames implements Comparator < Student >
{
  public int compare (Student a, Student b)
  {
    return a.name.compareTo (b.name);
  }
}
class sortByAge implements Comparator < Student >
{
  public int compare (Student a, Student b)
  {
    return a.age - b.age;
  }
}
class q4
{
  public static void main (String[]args)
  {

    //Scanner sc = new Scanner (System.in);
    BufferedReader br =
      new BufferedReader (new InputStreamReader (System.in));
      out.println ("Enter number of entry::");
    int n;
      List < Student > student = new ArrayList < Student > ();
      try
    {
      n = Integer.parseInt (br.readLine ());
      String name = "";
      int roll = -1, age = -1, i = 0;
      while (i < n)
	{
	  out.println ("Enter roll_number, age, name:" + (i + 1));
	  while (roll < 0 || age < 1 || name.equals (""))
	    {
	      roll = Integer.parseInt (br.readLine ());
	      age = Integer.parseInt (br.readLine ());
	      name = br.readLine ();
	      name = name.trim ();
	    }
	  Student temp = new Student (roll, age, name);
	  student.add (temp);
	  roll = -1;
	  age = -1;
	  name = "";
	  ++i;
	}
    }
    catch (Exception e)
    {
    }

    try
    {
      Collections.sort (student, new sortByAge ());
    }
    catch (Exception e)
    {
      out.println (e.getMessage ());
    }
    out.print ("This is sort by Age\n");
    out.println ("roll   name   age");
    for (int i = 0; i < student.size (); ++i)
      {
	Student temp = student.get (i);
	out.println (temp.r + " " + temp.name + " " + temp.age);
      }
    try
    {
      Collections.sort (student, new sortByNames ());
    }
    catch (Exception e)
    {
      out.println (e.getMessage ());
    }
    out.print ("This is sort by Names\n");
    out.println ("roll   name   age");
    for (int i = 0; i < student.size (); ++i)
      {
	Student temp = student.get (i);
	out.println (temp.r + " " + temp.name + " " + temp.age);
      }

  }
}
