import java.util.*;
import static java.lang.System.out;
class q1
{
  public static void main (String[]args)
  {
    HashMap < String, Integer > map = new HashMap < String, Integer > ();
    Scanner sc = new Scanner (System.in);
      out.println ("Enter numlber of entry::");
    int n = sc.nextInt ();
    String str;
    int con;
//sc.next();
      out.println ("Enter entries name and contact");
    while (n-- > 0)
      {
	str = sc.next ();
	con = sc.nextInt ();
	map.put (str, con);
      }
    /*for (Map.Entry mapEle:map.entrySet ()) //for mapEle there is getValue and getKey
      {
	out.println (mapEle);
      }*/
out.println("Enter the name of person name to search::");
str=sc.next();
if(map.containsKey(str)){
out.println(map.get(str));
}
else
out.println("Person not found");
    //out.println (map);
  }
}








/*
import java.util.*;
import static System.out;
class student implements Compartor<student>{
int roll,age;
String name;
student(){}
public int compare(student a, student b){
return a.roll-b.roll;
}
public int compare(student a, student b){
return a.name>b.name;
}
}

class q1{
public static void main(String[] args){

}
}
*/
