import java.io.*;


class FY implements Runnable
{

String mssg;
FY (String mssg)
{
	this.mssg=mssg;
}
	public void run()
	{
		System.out.println(mssg);
	}
}
class SY implements Runnable
{

String mssg;
SY (String mssg)
{
	this.mssg=mssg;
}
	public void run()
	{
		System.out.println(mssg);
	}
}
class TY implements Runnable
{
String mssg;
TY (String mssg)
{
	this.mssg=mssg;
}

	public void run()
	{
		System.out.println(mssg);
	}
}
class Ass2_2
{
public static void main(String args[]) throws Exception
{
	try{
	System.out.println("How many times To Display Welcome Mesage?");
	BufferedReader scan=new BufferedReader(new InputStreamReader(System.in));
	int count=Integer.parseInt(scan.readLine());
	String[3] mssg;
	System.out.println("Enter 3 Mesage?");
	for(int i=0;i<3;i++)
		mssg[i]=scan.readLine();
		
	for(int i=0;i<count;i++)
	{
	Thread fy=new Thread(new FY(mssg[0]));
	Thread sy=new Thread(new SY(mssg[1]));
	Thread ty=new Thread(new TY(mssg[2]));
	
		fy.start();
		fy.sleep(1000);
		sy.start();
		sy.sleep(1000);
		ty.start();
		ty.sleep(1000);
	}
	}
	catch (Exception e)
	{
		System.out.println(e.getMessage());
		System.exit(-1);
	}
}
}
