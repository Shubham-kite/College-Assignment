import java.io.*;


class FY implements Runnable
{
	public void run()
	{
		System.out.println("Welocome to FY");
	}
}
class SY implements Runnable
{
	public void run()
	{
		System.out.println("Welocome to SY");
	}
}
class TY implements Runnable
{

	public void run()
	{
		System.out.println("Welocome to TY");
	}
}
class Ass2_2
{
public static void main(String args[]) throws Exception
{
	try{
	System.out.println("How many times To Display Welcome Mesage?");
	BufferedReader scan=new BufferedReader(new InputStreamReader(System.in));
	int count=Integer.parseInt(scan.readLine());
		
	for(int i=0;i<count;i++)
	{
	Thread fy=new Thread(new FY());
	Thread sy=new Thread(new SY());
	Thread ty=new Thread(new TY());
	
		fy.start();
		fy.sleep(1000);
		sy.start();
		sy.sleep(1000);
		ty.start();
		ty.sleep(1000);
	}
	}
	catch (Exception e)
	{
		System.out.println(e.getMessage());
		System.exit(-1);
	}
}
}
