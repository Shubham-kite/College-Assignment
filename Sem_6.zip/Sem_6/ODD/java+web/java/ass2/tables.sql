drop table workload;
drop table teacher;
create table teacher(teacher_id int primary key,teacher_name varchar(20));
create table workload(teacher_id int references teacher(teacher_id) on delete cascade on update cascade,subject_code int primary key, subject varchar(20),date varchar(20), time varchar(20),class varchar(20));
insert into teacher values(1,'aaa');
insert into teacher values(2,'bbb');
insert into teacher values(3,'ccc');
insert into teacher values(4,'ddd');

insert into workload values(1,10,'matha','1/5/6','10:40','zz');
insert into workload values(2,11,'mathb','2/5/6','11:40','yy');
insert into workload values(3,12,'mathc','3/5/6','12:40','xx');
insert into workload values(4,13,'mathd','4/5/6','13:40','ww');

