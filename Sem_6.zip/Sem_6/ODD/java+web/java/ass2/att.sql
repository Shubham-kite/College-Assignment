drop table attendance;
create table attendance(rollno int primary key, class varchar(10), subject varchar(10),total int);
insert into attendance values(1,'aaa','matha',12);
insert into attendance values(2,'bbb','mathb',10);
insert into attendance values(3,'ccc','mathc',18);
insert into attendance values(4,'bbb','mathb',20);
insert into attendance values(5,'aaa','matha',15);
insert into attendance values(6,'ccc','mathc',16);
