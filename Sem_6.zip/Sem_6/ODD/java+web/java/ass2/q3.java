import java.sql.*;
import java.io.*;
class q3
{
  static final int total = 25;
  public static void main (String[]arg)
  {
    BufferedReader br =
      new BufferedReader (new InputStreamReader (System.in));
    Statement stmt = null;
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement ps = null;
    //PreparedStatement ps = null;
    int flag = 0, choice = -1;
    String str = "";
      try
    {
      //Class.forName ("org.postgresql.org");
      Class.forName ("org.postgresql.Driver");
      con =
	DriverManager.getConnection
	("jdbc:postgresql://192.168.16.1:5432/ty8719", "ty8719", "");
      System.out.println ("Getting prepared");
      if (con == null)
	{
	  System.out.println ("Not able to connect to databse");
	  System.exit (-1);
	}
      System.out.println ("Getting prepared");
      do
	{
	  System.out.println
	    ("1)Enter entery in database\n2)Show attendance table 3)Show outof 10 4)Exit");
	  choice = Integer.parseInt (br.readLine ());
	  switch (choice)
	    {
	    case 1:
	      {
		System.out.println
		  ("Enter rollno, name,class,subject,total attended");
		int roll = Integer.parseInt (br.readLine ());
		if(roll>26 && roll<0) {
		System.out.println("Total attendend should be less than 26");
		break;
		}
		String name = br.readLine ();
		String cls = br.readLine ();
		String subject = br.readLine ();
		flag=0;
		ps =
		  con.
		  prepareStatement
		  ("Select * from attendance where rollno=?");
		ps.setInt (1, roll);
		rs = ps.executeQuery ();
		flag = 0;
		while (rs.next ())
		  flag = 1;
		if (flag == 0)
		  {
		    ps =
		      con.prepareStatement
		      ("Insert into attendance values(?,?,?,?)");
		    ps.setInt (1, roll);
		    ps.setString (2, cls);
		    ps.setString (3, subject);
		    ps.setInt (4, roll);
		    flag = ps.executeUpdate ();
		    if (flag > 0)
		      System.out.println ("Inserted successfully");
		    else
		      System.out.println ("Not able to insert!!!");
		  }
		else
		  {
		    System.out.println
		      ("This roll number student is already present!!!");
		    break;
		  }
	      }
	      break;
	    case 2:
	      {
		int marks = 0;
		stmt = con.createStatement ();
		rs = stmt.executeQuery ("Select * from attendance");
		System.out.
		  println ("rollno class subject total_attended percentage");
		while (rs.next ())
		  {
		    System.out.print ("  " + rs.getInt (1) + "    ");
		    System.out.print (rs.getString (2) + "    ");
		    System.out.print (rs.getString (3) + "    ");
		    System.out.print (rs.getInt (4) + "  ");
		    double per = rs.getInt (4) * 100 / total;
		    System.out.println (per);
		  }
	      } break;
	      case 3:{
	      stmt=con.createStatement();
	      rs=stmt.executeQuery("Select total from attendance");
	      System.out.println("Attended   OUTOF 10");
	      while(rs.next()){
	       double per = rs.getInt (1) * 100 / total;
	       if(per<=100 && per>=90) System.out.println(rs.getInt(1)+"\t \t10");
	      else if(per<90 && per>=80) System.out.println(rs.getInt(1)+"\t\t9");
	      else if(per<90 && per>=70) System.out.println(rs.getInt(1)+"\t\t8");
	      else if(per<70 && per>=60) System.out.println(rs.getInt(1)+"\t\t7");
	      else if(per<60 && per>=50) System.out.println(rs.getInt(1)+"\t\t6");
	      else if(per<50 && per>=40) System.out.println(rs.getInt(1)+"\t\t5");
	      else if(per<40 && per>=30) System.out.println(rs.getInt(1)+"\t\t4");
	      else if(per<30 && per>=20) System.out.println(rs.getInt(1)+"\t\t3");
	      else if(per<20 && per>=10) System.out.println(rs.getInt(1)+"\t\t2");
	      else if(per<10 && per>=1) System.out.println(rs.getInt(1)+"\t\t1");
	      } 
	      }break;
	    case 4:
	      {
		//ps.close ();
		stmt.close ();
		con.close ();
		System.exit (-1);
	      }
	    }
	}
      while (choice > 0 && choice < 5);
    }
    catch (Exception e)
    {
      e.printStackTrace ();
    }
  }
}
