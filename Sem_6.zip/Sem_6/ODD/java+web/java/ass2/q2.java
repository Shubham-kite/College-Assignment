import java.sql.*;
import java.io.*;

class q2
{
  public static void main (String[]args)
  {
    BufferedReader br =
      new BufferedReader (new InputStreamReader (System.in));
    Statement stmt = null;
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement ps = null;
    int i, j, flag = 0, n, choice, id;
    String str;
      try
    {
      Class.forName ("org.postgresql.Driver");
      con =
	DriverManager.getConnection
	("jdbc:postgresql://192.168.16.1:5432/ty8719", "ty8719", "");
      if (con == null)
	{
	  System.out.println ("Failed to connect...!");
	  System.
	    out.println ("Note: Try after some time...May God blast you!!!");
	  System.exit (-1);
	}
      do
	{
	  System.out.println
	    ("1)Add record \n2)Class wise lecture detail of teacher\n3)Class time table\n4)Update 5)Teacher 6)Workload 7)delete 8)Exit");
	  choice = Integer.parseInt (br.readLine ());
	  switch (choice)
	    {
	    case 1:
	      {
		//System.out.println("You are");
		System.out.print ("Enter teacher id and teacher name:");
		id = Integer.parseInt (br.readLine ());
		str = br.readLine ();
		ps =
		  con.prepareStatement
		  ("Select * from teacher where teacher_id=?");
		ps.setInt (1, id);
		rs = ps.executeQuery ();
		flag = 0;
		while (rs.next ())
		  flag = 1;
		if (flag == 1)
		  {
		    System.out.
		      println ("This is entery is present in databse!!!");
		    break;
		  }
		else
		  {
		    ps =
		      con.prepareStatement
		      ("insert into teacher values(?,?)");
		    ps.setInt (1, id);
		    ps.setString (2, str);
		    flag = 0;
		    flag = ps.executeUpdate ();
		    if (flag > 0)
		      {
			System.out.println ("Inserted Successfully");
			System.out.println ("Enter worload for teacher id=" +
					    id);
			System.out.println ("Enter subject code:");
			int sc = Integer.parseInt (br.readLine ());
			System.out.println ("Enter subject name:");
			String subject = br.readLine ();
			System.out.println ("Enter date=>(x/x/x):");
			String date = br.readLine ();
			System.out.println ("Enter time=>(x:x)");
			String time = br.readLine ();
			System.out.println ("Enter class name:");
			String cls = br.readLine ();
			ps =
			  con.prepareStatement
			  ("insert into workload values(?,?,?,?,?,?)");
			ps.setInt (1, id);
			ps.setInt (2, sc);
			ps.setString (3, subject);
			ps.setString (4, date);
			ps.setString (5, time);
			ps.setString (6, cls);
			flag = 0;
			flag = ps.executeUpdate ();
			if (flag > 0)
			  System.out.
			    println ("Inserted workload successfully!");
			else
			  System.out.println ("Something went wrong!!!");
		      }
		    else
		      {
			System.out.println ("Not able to insert");
		      }
		  }
	      }
	      break;
	    case 2:
	      {
		System.out.print ("Enter teacher name:");
		str = br.readLine ();
		ps =
		  con.prepareStatement
		  ("Select * from workload where teacher_id in(select teacher_id from teacher where teacher_name=?)");
		ps.setString (1, str);
		flag = 0;
		rs = ps.executeQuery ();
		//System.out.println("Teacher id");
		while (rs.next ())
		  {
		    System.out.println("Teacher id="+rs.getInt (1) + " ");
		    System.out.println("Subject code=>"+rs.getInt (2) + " ");
		    System.out.println("subject name=>"+rs.getString (3) + " ");
		    System.out.println("date=>"+rs.getString (4) + " ");
		    System.out.println("Time=>"+rs.getString (5) + " ");
		    System.out.println ("Class name=>"+rs.getString (6));
		    flag = 1;
		  }
		if (flag == 0)
		  {
		    System.out.println ("Teacher is not present!!!");
		  }
	      }
	      break;
	    case 3:
	      {
		System.out.println ("Enter class name:");
		str = br.readLine ();
		ps =
		  con.prepareStatement
		  ("Select subject,date,time from workload where class=?");
		ps.setString (1, str);
		rs = ps.executeQuery ();
		flag = 0;
		while (rs.next ())
		  {
		    System.out.println ("Subject name=>"+rs.getString (1));
		    System.out.println ("Date=>"+rs.getString (2));
		    System.out.println ("Time=>"+rs.getString (3));
		    flag = 1;
		  }
		if (flag == 0)
		  System.out.println ("Class is not there!!!");
	      }break;
	    case 4:
	      {
		System.out.print ("Enter teacher id:");
		id = Integer.parseInt (br.readLine ());
		ps =
		  con.
		  prepareStatement
		  ("select * from  teacher where teacher_id=?");
		flag = 0;
		ps.setInt (1, id);
		rs = ps.executeQuery ();
		while (rs.next ())
		  flag = 1;
		if (flag == 1)
		  {
		    System.out.println ("Enter date, time, class:");
		    String date = br.readLine ();
		    String time = br.readLine ();
		    str = br.readLine ();
		    ps =
		      con.
		      prepareStatement
		      ("update teacher set date=?,time=?,class=? where teacher_id=?");
		    ps.setString (1, date);
		    ps.setString (2, time);
		    ps.setString (3, str);
		    ps.setInt (4, id);
		    flag = ps.executeUpdate ();
		    if (flag > 0)
		      System.out.println ("Record updated successfully!!");
		    else
		      System.out.println ("Something went wrong bhai!!!");
		  }
		else
		  System.out.println ("Teacher is not present");
	      }
	      break;
	    case 5:
	      {
		stmt = con.createStatement ();
		rs = stmt.executeQuery ("Select * from teacher");
		while (rs.next ())
		  {
		    System.out.print (rs.getInt (1) + " ");
		    System.out.println (rs.getString (2));
		  }
	      }
	      break;
	    case 6:
	      {
		stmt = con.createStatement ();
		rs = stmt.executeQuery ("Select * from workload");
		while (rs.next ())
		  {
		    System.out.print (rs.getInt (1) + " ");
		    System.out.print (rs.getInt (2) + " ");
		    System.out.print (rs.getString (3) + " ");
		    System.out.print (rs.getString (4) + " ");
		    System.out.print (rs.getString (5) + " ");
		    System.out.println (rs.getString (6));
		  }
	      }
	      break;
	    case 7:
	      {
		System.out.println ("Enter passcode:");
		int code = Integer.parseInt (br.readLine ());
		if (code == 1729)
		  {
		    id = Integer.parseInt (br.readLine ());
		    ps =
		      con.
		      prepareStatement
		      ("Delete from teacher where teacher_id=?");
		    ps.setInt (1, id);
		    flag = 0;
		    flag = ps.executeUpdate ();
		    if (flag > 0)
		      {
			System.out.println ("Deleted successfully");
		      }
		    else
		      System.out.println ("Not able to delete");
		  }
		  else 
	      System.out.println("You are not right to delete");
	      }
	      
	      break;
	    case 8:
	      System.exit (-1);
	    }
	}
      while (choice > 0 && choice < 8);
      /*con.close ();
         stmt.close ();
         rs.close (); */
    }
    catch (Exception e)
    {
    }
  }
}
