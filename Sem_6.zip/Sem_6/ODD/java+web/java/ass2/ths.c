void
ArrayChallenge (int arr[], int arrLength)
{
//comment printf("%d", arr[0]);from original code....
  int i, j;
  for (i = 1; i < arrLength; ++i)
    {
      for (j = i + 1; j < arrLength; ++j)
	{
	  if (arr[i] + arr[j] == arr[0])
	    {
	      printf ("%d,%d\n", arr[i], arr[j]);
	    }
	}
    }
}
