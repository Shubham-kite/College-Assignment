#include<stdio.h>
#include<stdlib.h>
int **max,**allo,i,j,k=0,np,nr,*avail,A,B,C;
void max_matrix();
void allo_matrix();
void inital_avail();
int main()
{
	printf("\nEnter Number of process");
	scanf("%d",&np);
	printf("\nEnter Number of resources");
        scanf("%d",&nr);
	avail=(int *)malloc(nr*sizeof(int *));
	printf("\nEnter Total  Number Of Instances of each Resources\n");
	for(i=0;i<nr;i++)
	{
		printf("\nEnter Total  Number Of Instances  R%d\t",i);
		scanf("%d",&avail[i]);
	}
	allo_matrix();
	max_matrix();
	inital_avail();

}
void max_matrix()
{

	max=(int **)malloc(np*sizeof(int *));
	for(i=0;i<np;i++)
	{
		max[i]=(int *)malloc(nr*sizeof(int *));
	}
       // allo=(int **)malloc(np*sizeof(int *));
        printf("\nEnter Maximum Matrix");
        for(i=0;i<np;i++)
        { 
                printf("\nEnter Maximum resources of:P%d\t",i);
                for(j=0;j<nr;j++)
                {
                        scanf("%d",&max[i][j]);
                }
        }
        printf("\nMaximum Matrix is\n");
	for(i=0;i<np;i++)
        { 
                for(j=0;j<nr;j++)
                {
                        printf("%d\t",max[i][j]);
                }
		printf("\n");
        }

}
void allo_matrix()
{
	allo=(int **)malloc(np*sizeof(int *));
	for(i=0;i<np;i++)
	{
		allo[i]=(int *)malloc(nr*sizeof(int *));
	}
       // allo=(int **)malloc(np*sizeof(int *));
        printf("\nEnter Allocation Matrix");
        for(i=0;i<np;i++)
        { 
                printf("\nEnter Allocation resources of:P%d\t",i);
                for(j=0;j<nr;j++)
                {
                        scanf("%d",&allo[i][j]);
                }
        }
        printf("\nAllocation Matrix is\n");
	for(i=0;i<np;i++)
        { 
                for(j=0;j<nr;j++)
                {
                        printf("%d\t",allo[i][j]);
                }
		printf("\n");
        }

}
void inital_avail()
{	
	int A=0,B=0,C=0,k,m;
	for(i=0;i<np;i++)
	{
		for(j=0;j<nr;j++)
		{
			avail[i]=avail[i]-allo[i][j];
		}

		
	}
	printf("\n Initial Available resorces For P1 Proces\n");
	for(i=0;i<nr;i++)
        {
               // printf("\nEnter Total  Number Of Instances  R%d\t",i);
                printf("%d",avail[i]);
        }


}

