#include<stdlib.h>
#include<stdio.h>
int
main (void)
{
  int *avl, *ft;
  int **need, **all, **max;
  int good = 0;
  int flag = 0;
  int n = 0, m = 0, i, j, temp;
  printf ("Enter number of processes:");
  while (n < 1)
    scanf ("%d", &n);
  printf ("Enter number of resources:");
  while (m < 1)
    scanf ("%d", &m);
  temp = 0;
  avl = (int *) malloc (sizeof (m));

  while (temp < m)
    {
      printf ("Enter the instances of %d Resouces type:", temp);
      scanf ("%d", &avl[temp]);
      ++temp;
    }
  temp = 0;
  max = (int **) malloc (sizeof (n));
  for (i = 0; i < n; ++i)
    {
      max[i] = (int *) malloc (sizeof (m));
      for (j = 0; j < m; ++j)
	{
	  printf
	    ("\nEnter the maximum requirment of %d process for %d resouce type:",
	     i, j);
	  max[i][j] = 100;
	  while (max[i][j] > avl[j] || max[i][j] < 0)
	    {
	      if (flag)
		printf ("Enter valid entry!!!");
	      scanf ("%d", &max[i][j]);
	      flag = 1;
	    }
	}
    }
  printf
    ("..............Enter now for Allocated Resources to each process.................");
  all = (int **) malloc (sizeof (n));
  for (i = 0; i < n; ++i)
    {
      all[i] = (int *) malloc (sizeof (m));
      for (j = 0; j < m; ++j)
	{
	  printf ("\nEnter the allocated to %d process of %d resouce type:",
		  i, j);
	  temp=100;
	  while (temp > max[i][j] || max[i][j] < 0)
	    {
	      if (flag)
		printf ("Enter valid entries !!!");
	      scanf ("%d", &temp);
	      flag = 1;
	    }
	    all[i][j] = temp;
	}
    }
  for (i = 0; i < n; ++i)
    {
      for (j = 0; j < m; ++j)
	{
	  need[i][j] = max[i][j] - all[i][j];
	}
    }
  ft = (int *) malloc (sizeof (n));
  for (i = 0; i < n; ++i)
    ft[i] = 0;

  do
    {
      good = 0;
      flag = 1;
      for (i = 0; i < n; ++i)
	{
	  if (ft[i] == 0)
	    {
	      for (j = 0; j < m; ++j)
		{
		  if (avl[j] < need[i][j])
		    flag = 0;
		}
	      if (flag)
		{
		  ft[i] = 1;
		  for (j = 0; j < m; ++j)
		    {
		      avl[j] += all[i][j];
		    }
		  good = 1;
		  printf ("%d", i);
		}
	    }
	}
    }
  while (good);

  for (i = 0; i < n; ++i)
    if (ft[i] == 0)
      {
	printf ("System is not in safe");
	return 0;
      }
  printf ("System is in Safe");
  return 0;
}
