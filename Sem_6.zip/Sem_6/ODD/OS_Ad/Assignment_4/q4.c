#include<stdio.h>
#include<stdlib.h>
void display (int **, int, int);
void accept (int **, int, int, char *);
int i, j, k, flag;
int *avl;
int
main (int argc, char const *argv[]) 
{
  int **need, **all, **max;
  int *ft, *work;
  int n = -1, m = -1, good;
  printf ("Enter the number of processes:\n");
  while (n < 1)
    scanf ("%d", &n);
  printf ("Enter number of resources types:\n");
  while (m < 1)
    scanf ("%d", &m);
  avl = (int *) malloc (sizeof (m));
  work = (int *) malloc (sizeof (m));
  for (j = 0; j < m; ++j)
    {
      printf ("Enter the instance of resource types %d:", j);
      scanf ("%d", &avl[j]);
    }
  
    //for(j=0;j<m;++j)
    //for(i=0;i<n;++i)
    max = (int **) malloc (sizeof (n));
  all = (int **) malloc (sizeof (n));
  need = (int **) malloc (sizeof (n));
  for (i = 0; i < n; ++i)
    {
      max[i] = (int *) malloc (sizeof (m));
      for (j = 0; j < m; ++j)
	{
	  printf
	    ("Enter the maximum need for process %d of resource type %d:", i,
	     j);
	  max[i][j] = -1;
	  flag = 0;
	  while (max[i][j] < 0 || max[i][j] > avl[j])
	    {
	      if (flag)
		printf ("Enter valid entries!!!");
	      flag = 1;
	      scanf ("%d", &max[i][j]);
	    }
	}
    }
  printf ("This is maximum need matrix\n");
  display (max, n, m);
  for (i = 0; i < n; ++i)
    {
      all[i] = (int *) malloc (sizeof (m));
      for (j = 0; j < m; ++j)
	{
	  all[i][j] = max[i][j] + 1;
	  flag = 0;
	  printf
	    ("Enter the allocated resorces to process %d of resource type %d:",
	     i, j);
	  while (all[i][j] > max[i][j] || all[i][j] < 0 || all[i][j]>avl[j])
	    {
	      if (flag)
		printf ("Enter valid entries!!!");
	      flag = 1;
	      scanf ("%d", &all[i][j]);
	    }
avl[j] = avl[j] - all[i][j];
	}
    }				/*
				   accept(max,n,m,"maximum need");
				   printf("This is maximum need matrix\n");
				   display(max,n,m);
				   accept(all,n,m,"allocated"); */
  printf ("This is allocated matrix\n");
  display (all, n, m);
  
    //calculating the available resouces after allocation to each process...
    for (i = 0; i < n; ++i)
    {
      need[i] = (int *) malloc (sizeof (m));
      for (j = 0; j < m; ++j)
	{
	  need[i][j] = max[i][j] - all[i][j];
	  
	}
      
	//avl[i]=avl[i]-flag;
    }
  printf ("This is need matrix for processes now\n");
  display (need, n, m);
  printf ("After allocating the resouces we have ...!\n");
  for (j = 0; j < m; ++j)
    {
      printf ("Type %d => Available%d\n", j, avl[j]);
      work[j] = avl[j];
    }
  
    ///checking now system is in safe or not
    ft = (int *) malloc (sizeof (n));
  for (i = 0; i < n; ++i)
    {
      ft[i] = 0;
    }
  
    //printf("Here is process sequence:\n  ");
    do
    {
      good = 0;
      for (i = 0; i < n; ++i)
	{
	  flag = 1;
	  if (ft[i] == 0)
	    {
	      for (j = 0; j < m; ++j)
		if (need[i][j] > work[j])
		  {
		    flag = 0;
		    break;
		  }
	      if (flag)
		{
		  good = 1;
		  ft[i] = 1;
		  for (k = 0; k < m; ++k)
		    work[k] += all[i][k];
		  printf ("%d =>", i);
		}
	    }
	}
    }
  while (good);
  for (i = 0; i < n; ++i)
    {
      if (ft[i] != 1)
	printf ("\nAlert! \"System is not in safe\"!!!"), exit (0);
    }
  printf ("System is in safe😍✌️");
  return 0;
}

void
display (int **mat, int n, int m)
{
  
//int i,j;
    for (i = 0; i < n; ++i)
    {
      
	//flag=0;
	for (j = 0; j < m; ++j)
	{
	  printf ("%d ", mat[i][j]);
	}
      printf ("\n");
    }
}


/*
void accept(int **mat,int n,int m,char *str){
//int i,j,flag;
	for(i=0;i<n;++i){
		mat[i]=(int*)malloc(sizeof(m));
		for(j=0;j<m;++j){
			printf("Enter the %s for process %d of resource type %d:",str,i,j);
			mat[i][j]=-1;
			flag=0;
			while(mat[i][j]<0 || mat[i]>avl[j]){
				if(flag) printf("Enter valid entries!!!");
				flag=1;
				scanf("%d",&mat[i][j]);
			}
		}
	}
}*/
