#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct pcb
{
	int pid,at,cbt,pri,wt,tat,comp;
};

struct rq
{
	int pid,at,cbt,pri;
	struct rq *next;
}*head,*rtemp,*rnew ;

struct gchart
{
	int pid,start,finish;
	struct gchart *next;
	
}*head,*temp,*new,*curr;

int nop,count=-1,iflag=0,pr=-1,time=0;
struct pcb *p;
float avgwt=0,avgtat=0;

int main()
{
	int at,i,ch1,flag;
	char ch;
	head=(struct gchart*)malloc(sizeof(struct gchart));
	head->next=NULL;
	rhead=(struct rq*)malloc(sizeof(struct rq));
	rhead->next=NULL;
	do{
		printf("\n How Many Processes?\n");
		scanf("%d",&nop);
		if(nop<=0)
		{
		  printf("\n Invalid Number of Processes");
		}



	}while(nop<=0);
	p=(struct pcb*)malloc(sizeof(struct pcb));
	do
	{
		printf("\n Do all ");
	}
	
	
	
	




}
