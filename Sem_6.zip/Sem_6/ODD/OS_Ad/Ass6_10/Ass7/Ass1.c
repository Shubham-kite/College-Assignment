#include<stdio.h>
#include<stdlib.h>
typedef struct index
{
char file_name[10];
int index;
int indexblock[10];
struct index *next;
}index;

index *head,*next;

int *bit_vector;
int disk_size;

int main()
{

void display();
int choice;


printf("\nWhat is the size of disk?");
scanf("%d",&disk_size);
bit_vector=malloc(sizeof(int)* disk_size);
if(bit_vector==NULL)
{
	printf("\nUnable to allocate memory\n");
}

//Disk is free
for(int i=0;i<disk_size;i++)
	bit_vector[i]=1;
	
display();
while(1)
{
printf("\n1)Create file\n2)Delete file\n3)Exit\nEnter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:
	{
	char temp_file[25];
	printf("\nEnter file name:");
	scanf("%s",&temp_file);
	printf("\nHow much disk you required:");
	scanf("%d",&choice);
	if(choice >disk_size)
	{
		if(check_disk(choice))
		{
			
		
		}
		else
			printf("\n\t DISK IS NOT AVILABLE OF SIZE <%d>",choice);
	}
	else
		printf("\n\t DISK IS NOT AVILABLE OF SIZE <%d>",choice);
	
	}
	break;
	
case 2:
	{
	if(head)
	{
		char temp_file[25];
		printf("\nEnter file name to be deleted:");
		scanf("%s",&temp_file);
	
		if(delete_entry(temp_file))
		{
			printf("\n\t\t FILE WITH NAME \" %s \" DELETED SUCCESSFULLY",temp_file);			
			display();
			show_directory();
		}
		else
			printf("\n\t\tNO FILE WITH NAME \" %s \" EXIST",temp_file);
	
	}
	else
		printf("\n\t\tDISK IS EMPTY");
	}
	break;
case 3:
	exit(0);
default:
	printf("\nInvalid input");		
	break;
}	
}


}
void display()
{
	printf("\n\t\t");
	for(int i=0;i<disk_size;i++)
		printf(" %d ",bit_vector[i]);
}


int check_disk(int checksize)
{
	int disk_count_free=0;
	for(int i=0;i<disk_size;i++)
	{	
		for(int j=i;j<disk_size;j++)
		{
			if(bit_vector[j]==1)
			{	disk_count_free++;	
				if(disk_count_free==checksize)
					return 1;
			}
			else
				break;
		}
	}
	return -1;
}

