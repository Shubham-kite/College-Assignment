#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<strings.h>
#include<stdbool.h>
typedef struct dir_entry
{
int length;
int base;
char file_name[10];
struct dir_entry *next;
}dir_entry;

dir_entry *head,*current,*temp;

int *bit_vector;
int disk_size;

int main()
{

void display();
int check_disk(int checksize);
void new_entry_directory(char file[25],int base,int length);
int delete_entry(char file[25]);
void delete(int base,int length);
void show_directory();
int check_file(char file[25]);
int choice;
printf("\nWhat is the size of disk?");
scanf("%d",&disk_size);
bit_vector=malloc(sizeof(int)* disk_size);
if(bit_vector==NULL)
{
	printf("\nUnbale to allocate memory\n");
}

//Disk is free
for(int i=0;i<disk_size;i++)
	bit_vector[i]=1;
	
display();
while(1)
{
printf("\n1)Create file\n2)Delete file\n3)Exit\nEnter your choice");
scanf("%d",&choice);
switch(choice)
{
case 1:
	{
	char temp_file[25];
	printf("\nEnter file name:");
	scanf("%s",&temp_file);
	printf("\nHow much disk you required:");
	scanf("%d",&choice);
	int base=check_disk(choice);
	if(base>=0)
	{
		printf("base-%d",base);
		if(check_file(temp_file)<0)
		{
			for(int i=base;i<(base+choice);i++)
				bit_vector[i]=0;
		
			new_entry_directory(temp_file,base,choice);
			printf("\nFile created Successfully");
			display();
			show_directory();
		}
		else
			printf("\n\t\tFILE NAME ALREDAY EXIST");
	}
	else
		printf("\n\tCONTINOUS DISK IS NOT AVILABLE OF SIZE <%d>",choice);
	
	}
	break;
	
case 2:
	{
	if(head)
	{
		char temp_file[25];
		printf("\nEnter file name to be deleted:");
		scanf("%s",&temp_file);
	
		if(delete_entry(temp_file))
		{
			printf("\n\t\t FILE WITH NAME \" %s \" DELETED SUCCESSFULLY",temp_file);			
			display();
			show_directory();
			//system("rm -rf ../../");
		}
		else
			printf("\n\t\tNO FILE WITH NAME \" %s \" EXIST",temp_file);
	
	}
	else
		printf("\n\t\tDISK IS EMPTY");
	}
	break;
case 3:
	exit(0);
default:
	printf("\nInvalid input");		
	break;
}	
}


}

void new_entry_directory(char file[25],int base,int length)
{
if(!head)
{
	head=malloc(sizeof(dir_entry));
	strcpy(head->file_name,file);
	head->length=length;
	head->base=base;
	head->next=NULL;
}
else
{
	
	temp=current=head;
	current=malloc(sizeof(dir_entry));
	strcpy(current->file_name,file);
	current->length=length;
	current->base=base;
	current->next=NULL;
	
	while(temp->next!=NULL)
		temp=temp->next;
	temp->next=current;
	
}
}

int check_file(char file[25])
{
current=head;
while(current!=NULL)	
{
	if(strcasecmp(current->file_name,file)==0)
	{
		return 1;
	}
	current=current->next;
}

return -1;
}

int delete_entry(char file[25])
{
void delete(int base,int length);

	dir_entry *previous,*next;
	current=head;
	if(strcasecmp(head->file_name,file)==0)
	{
		delete(head->base,head->length);
		head=head->next;
		free(current);
		return 1;
	}
	current=head->next;
	next=head->next->next;
	previous=head;
	while(current!=NULL)	
	{
		if(strcasecmp(current->file_name,file)==0)
		{
			delete(current->base,current->length);
			previous->next=next;
			free(current);
			return 1;
		}
		previous=previous->next;
		current=current->next;
		next=next->next;
	}
	
	return -1;	
}

void delete(int base,int length)
{
	for(int i=base;i<base+length;i++)
		bit_vector[i]=1;
}

int check_disk(int checksize)
{
	int disk_count_free=0;
	for(int i=0;i<disk_size;i++)
	{	disk_count_free=0;
		for(int j=i;j<disk_size;j++)
		{
			if(bit_vector[j]==1)
			{	disk_count_free++;	
				if(disk_count_free==checksize)
					return i;
			}
			else
				break;
		}
	}
	return -1;
}
void display()
{
	printf("\n\t\t");
	for(int i=0;i<disk_size;i++)
		printf(" %d ",bit_vector[i]);
}

void show_directory()
{
	current=head;
	printf("\n\nFile Name\tBase\tLength");
	while(current!=NULL)
	{
		printf("\n%s\t\t%d\t%d",current->file_name,current->base,current->length);
		current=current->next;
	}
	printf("\n");
}


