#include<stdio.h>
#include<stdlib.h>

int *str, **frame, n, p, pf = 0,hits=0;;
static int counter = 1;

int search (int, int *);
void lru ();
void
display ()
{
  int i;
  for (i = 0; i < n; ++i)
    if (frame[i][0] != -1)
      printf ("%d ", frame[i][0]);
    else
      printf ("0 ");
  printf ("\n");
}

int
search (int k, int *indx)
{
  int m = frame[0][1];
  *indx = 0;
  int i;
  for (i = 0; i < n; ++i)
    {
      if (frame[i][1] == -1)
	{
	  *indx = i;
	  return 0;
	}
      if (frame[i][0] == k)
	return 1;
      if (frame[i][1] < m)
	m = frame[i][1], *indx = i;
    }
  return 0;
}

void
lru ()
{
  int i, min, indx;
  printf ("This is page Replacement table\n");
  for (i = 0; i < p; ++i)
    {
      if (!search (str[i], &indx))
	{
	  frame[indx][0] = str[i];
	  frame[indx][1] = counter;
	  ++counter;
	  ++pf;
	  display ();
	}
	else {
	++hits;
	printf("Page hit for %d\n",str[i]);
	}
    }
}


int
main (void)
{
  int i;
  printf ("\nEnter No. of Pages: ");
  scanf ("%d", &p);
  str = (int *) malloc (p * sizeof (int));
  printf ("\nEnter Reference String: ");
  for (i = 0; i < p; i++)
    scanf ("%d", &str[i]);
  printf ("\nEnter No. of Frames: ");
  scanf ("%d", &n);
  frame = (int **) malloc (n * sizeof (int));
  for (i = 0; i < n; ++i)
    {
      frame[i] = (int *) malloc (sizeof (2));
      frame[i][0] = -1;
      frame[i][1] = -1;
    }
  lru ();
  printf ("Total number of page fault=%d and Page hits=%d\n", pf,hits);
}

/*
int *str,*frame,p,n,i;

int search(int key){for(i=0;i<n;i++)if(frame[i]==key)return i;return -1;}

void shift(int z){int r=frame[z];for(i=z;i<n;i++)frame[i]=frame[i+1];frame[i]=r;}

void display(){for(i=0;i<n;i++)printf("%d ",frame[i]);printf("\n");}

void LRU()
{
	int k=-1,c=0,i,z;
	printf("\n\nPage Replacement Table\n");
	while(c<n)
	{
		k++;
		z=search(str[k]);
		if(z!=-1){shift(z);display();continue;}
		else 
		{
			frame[0]=str[k];
			shift(0);
			display();c++;
		}

	} 
	
	while(k<p)
	{
		k++;
		z=search(str[k]);
		if(z!=-1){
			shift(z);
			display();
			continue;}
		else
		{
			frame[0]=str[k];
			shift(0);
			display();c++;
		}
	}
	printf("\n\nNo. of Page Faults: %d\n",c);
}

void main()
{
	int i;
	printf("\nEnter No. of Pages: ");
	scanf("%d",&p);
	str=(int*)malloc(p*sizeof(int));
	printf("\nEnter Reference String: ");
	for(i=0;i<p;i++)scanf("%d",&str[i]);
	printf("\nEnter No. of Frames: ");
	scanf("%d",&n);
	/*frame=(int**)malloc(n*sizeof(int*));
	for(i=0;i<n;i++)
	frame=(int*)malloc(2*sizeof(int));


	frame=(int*)malloc(n*sizeof(int));
	LRU();
}*/
