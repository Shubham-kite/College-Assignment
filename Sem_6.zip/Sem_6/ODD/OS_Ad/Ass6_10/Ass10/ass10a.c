#include<stdio.h>
#include<stdlib.h>
int *str,**frame,p,n,i;
int sort()
{
	int key=0,time=100,m=0;
	for(i=0;i<n;i++)
		if(frame[i][1]<key)
		{key=frame[i][1];time=frame[i][2];m=i;}

		else if(frame[i][1]==key)
		{if(frame[i][2]>time){key=frame[i][1];time=frame[i][2];m=i;}}	

	return m;
}

int search(int key){for(i=0;i<n;i++)if(frame[i][0]==key)return i;return -1;}

void display(){for(i=0;i<n;i++)printf("%d ",frame[i][0]);printf("\n");}

void MFU()
{
	int k=-1,c=0,i,z,x=0,time=0;
	printf("\n\nPage Replacement Table\n\n");
	while(c<n)
	{
		k++;time++;
		z=search(str[k]);
		if(z!=-1){frame[z][1]++;frame[z][2]=time;printf("\n Page: %d    Already Exists\n ",str[k]);continue;}
		else 
		{
			frame[c][0]=str[k];
			frame[c][1]++;
			frame[c][2]=time;
			printf("\n Page: %d    ",str[k]); 
			display();
			c++;
		}
	}	
	while(k<p-1)
	{
		k++;time++;
		z=search(str[k]);
		if(z!=-1){frame[z][1]++;frame[z][2]=time;printf("\n Page: %d    Already Exists\n ",str[k]);continue;}
		else
		{
			z=sort();
			frame[z][0]=str[k];
			frame[z][1]=1;
			frame[z][2]=time;
			printf("\n Page: %d    ",str[k]); 
			display();c++;
		}
	}
	printf("\n\nNo. of Page Faults: %d\n",c);
}

void main()
{
	int i;
	printf("\nEnter No. of Pages: ");
	scanf("%d",&p);
	str=(int*)malloc(p*sizeof(int));
	printf("\nEnter Reference String: ");
	for(i=0;i<p;i++)scanf("%d",&str[i]);
	printf("\nEnter No. of Frames: ");
	scanf("%d",&n);
	frame=(int**)malloc(n*sizeof(int*));
	for(i=0;i<n;i++)
	frame[i]=(int*)malloc(3*sizeof(int));
	MFU();
}
