//do not indent this file....
#include<stdio.h>
#include<stdlib.h>
void display(int **, int , int);
void accept(int **, int, int, char *);
int isSystemSafe(int **, int **, int *, int *, int, int);
int i, j,k,flag;
int *avl;
int main(int argc, char const *argv[])
{
	int **need, **all, **max;
	int *ft, *work, *req;
	int n = -1, m = -1, good, p;
	printf("Enter the number of processes:\n");
	while (n < 1)
		scanf("%d", &n);
	printf("Enter number of resources types:\n");
	while (m < 1)
		scanf("%d", &m);
	avl = (int*)malloc(sizeof(m));
	work = (int*)malloc(sizeof(m));
	req = (int*)malloc(sizeof(m));
	for (j = 0; j < m; ++j) {
		printf("Enter the instance of resource types %d:", j);
		scanf("%d", &avl[j]);
	}
	//for(j=0;j<m;++j)
	//for(i=0;i<n;++i)
	max = (int**)malloc(sizeof(n));
	all = (int**)malloc(sizeof(n));
	need = (int**)malloc(sizeof(n));
	ft = (int*)malloc(sizeof(n));
	for (i = 0; i < n; ++i) {
		max[i] = (int*)malloc(sizeof(m));
		for (j = 0; j < m; ++j) {
			printf("Enter the maximum need for process %d of resource type %d:", i, j);
			max[i][j] = -1;
			flag = 0;
			while (max[i][j] < 0 || max[i][j] > avl[j]) {
				if (flag) printf("Enter valid entries!!!");
				flag = 1;
				scanf("%d", &max[i][j]);
			}
		}
	}
	printf("This is maximum need matrix\n");
	display(max, n, m);
	for (i = 0; i < n; ++i) {
		all[i] = (int*)malloc(sizeof(m));
		for (j = 0; j < m; ++j) {
			all[i][j] = max[i][j] + 1;
			flag = 0;
			printf("Enter the allocated resorces to process %d of resource type %d:", i, j);
			while (all[i][j] > max[i][j] || all[i][j] < 0 || all[i][j]>avl[j]) {
				if (flag) printf("Enter valid entries!!!");
				flag = 1;
				scanf("%d", &all[i][j]);
			}
			avl[j] = avl[j] - all[i][j];			
		}
	}/*
	accept(max,n,m,"maximum need");
	printf("This is maximum need matrix\n");
	display(max,n,m);
	accept(all,n,m,"allocated");*/
	printf("This is allocated matrix\n");
	display(all, n, m);
	//calculating the available resouces after allocation to each process...
	for (i = 0; i < n; ++i) {
		need[i] = (int*)malloc(sizeof(m));
		for (j = 0; j < m; ++j) {
			need[i][j] = max[i][j] - all[i][j];
		}
		//avl[i]=avl[i]-flag;
	}
	printf("This is need matrix for processes now\n");
 	display(need, n, m);
	printf("After allocating the resouces we have ...!\n");
	for (j = 0; j < m; ++j) {
		printf("Type %d => Available%d\n", j, avl[j]);
		work[j] = avl[j];
		ft[j] = 0;
	}
	p = m + 1;
	flag = 0;
	printf("Enter the request process id:");
	while (p >= n) {
		if (flag) printf("Enter valid process!!");
		scanf("%d", &p);
		flag = 1;
	}
	good=1;
	printf("Enter the instaces of resource types requested\n");
	for (i = 0; i < n; ++i) {
		printf("Enter resource type %d requested ", i);
		scanf("%d", &req[i]);
		if (req[i] > need[p][i]) {
			printf("Can't be granted this request because exceeded its maximum claim");
			good = 0;
			break;
		}
		if (req[i] > work[i]) {
			printf("Can't be granted so this process must wait for some time...!");
			good = 0;
		}
	}
	if(good){
		for(i=0;i<n;++i){
			work[i]-=req[i];//work is temp array for avl
			//work[i]=avl[i];
			all[p][i]+=req[i];
			need[p][i]=max[p][i]-all[p][i];
		}
	}
	printf("After the allocation\n");
	display(all,n,m);
	printf("This is need marix\n");
	display(need,n,m);
	printf("This is Available resouces=>");
	for(i=0;i<n;++i)
		printf("%d ",work[i]);
	printf("\n");
	if (isSystemSafe(need, all, work, ft, n, m)){
		printf("System is in safe😍✌️");
		printf("\nAllocation is granted");
		exit(0);
	}
	else{
		printf("System is not in safe\n");
		printf("So %d process must wait\n",p);
	}
	for (i = 0; i < n; ++i){
		work[i]=avl[i];
		all[p][i]-=req[i];
		need[p][i]=max[p][i]-all[p][i];
	}
	printf("So this is old state is restored!\n");
	printf("Allocation matrix is\n");
	display(all,n,m);
	printf("This is need matrix\n");
	display(need,n,m);
	return 0;
}

int isSystemSafe(int **need, int **all, int *work, int *ft, int n, int m) {
	int good;
	do {
		good = 0;
		for (i = 0; i < n; ++i) {
			flag = 1;
			if (ft[i] == 0) {
				for (j = 0; j < m; ++j){
					printf("%d ",need[i][j]);
					if (need[i][j] > work[j]) {
						flag = 0;
						break;
					}
				}
				if (flag) {
					good = 1;
					ft[i] = 1;
					for (k = 0; k < m; ++k)
						work[k] += all[i][k];
					/*printf("This is work array \n");
					for(int x=0;x<m;++x){
						printf("%d ",work[x]);
					}*/
					printf("%d =>", i);
				}
			}
			//printf("\n");
		}
	} while (good);
	for (i = 0; i < n; ++i) {
		if (ft[i] != 1)
			return 0;;
	}
	return 1;
}

void display(int **mat, int n, int m) {
//int i,j;
	for (i = 0; i < n; ++i) {
		//flag=0;
		for (j = 0; j < m; ++j) {
			printf("%d ", mat[i][j]);
		}
		printf("\n");
	}
}
/*
void accept(int **mat,int n,int m,char *str){
//int i,j,flag;
	for(i=0;i<n;++i){
		mat[i]=(int*)malloc(sizeof(m));
		for(j=0;j<m;++j){
			printf("Enter the %s for process %d of resource type %d:",str,i,j);
			mat[i][j]=-1;
			flag=0;
			while(mat[i][j]<0 || mat[i]>avl[j]){
				if(flag) printf("Enter valid entries!!!");
				flag=1;
				scanf("%d",&mat[i][j]);
			}
		}
	}
}*/
