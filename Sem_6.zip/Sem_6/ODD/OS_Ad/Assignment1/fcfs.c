#include<stdio.h>
#include<stdlib.h>

typedef struct node{

		int no;
		float at,bt,st,wt,ft,tat;
		struct node *next;
	

}NODE;

int process,c=0;
float S_time=0.0,idle[100];

void create_insert(NODE **P,int no,float at,float bt)
{

NODE *q,*r=*p;
q=(NODE*)malloc(sizeof(NODE));
q->no=no+1;
q->at=at;
q->bt=bt;
q->next=NULL;
if(*p==NULL)
{
	*p=q;

}
else
{
	while(r->next!=NULL)
	{
		r=r->next;
	}
	r->next=q;
}
}

void display_sort(NODE *p)
{
	NODE *r=p;
printf("\n===================================================\n|processId |A.T  |B.T  |\n================= ");
	while(r)
	{
		printf("\n| p%d  | %.2f  | %.2f |",r->no,r->at,r->bt);
			r=r->next;
	}


}
int calculate(NODE **p)
{
	NODE *q=*p,*r=*p;
	int c1=0,c2;
	printf("\n--------------------------------------------------------------------");
	printf("\n|process | A.T  | B.T  | S.T  | W.T   |F.T   | T.A.T  ");
	printf("-----------------------------------------------------------------------");
	while(q)
	{
		c2=0;
		if(c1==0)
		{
			if(q->atS_time)
			{
				idle[c++]=0.0;
				idle[c++]=q->at;
				S_time=q->at;
				c2=2;
				
			}
			else
			{

				q->st=q->at;
				q->wt=q->at;
				idle[c++]=q->st;
				c1++;
			}
	        }
		else
		{
			if(q->at>S_time)
			{
				q->st=S_time + (q->at-S_time);
				q->wt=q->st-q->at;
				idle[c++]=q->st;
				idle[c++]=q->at;

			}
	        	else
			{
				q->st=S_time;
				q->wt=q->st-q->at;
				idle[c++]=q->st;
			
			}


                        
                }
		 if(c2!=2)
                  {
                                q->ft=q->st+q->bt;
                                idle[c++]=q->ft;
                                q->tat=q->ft-q->at;
                                S_time=q->ft;
                                printf("\n| p%d  | %.2f  | %.2f | %.2f  | %.2f | %.2f |",q->no,q->at,q->bt,q->st,q->wt,q->ft,q->tat);
                                        q=q->next;

                                                     
                                        
                   }






	
        }
	return c;

}

void main()
{
	NODE *head=NULL;
	char ch;
	int i=0,j,k;
	float arr_time,burst_time,first_response,tmp;
	do{
		printf("\n <== Enter process details ==>");
		printf("\n Arrival Time :");
		scanf("%f",&arr_time);
		printf("\n Burst Time :");
		scanf("%f",&burst_time);
		
		create_insert(&head,process,arr_time,burst_time);
		process++;
		printf("Is there any other process (Y/N) ==>");
		scanf("%d",&i);
		scanf("%c",&ch);
	}while(ch=='y' || ch=='Y' ); //it shoud br n
	printf("\t process list");
	display_sort(head);
	c=calculate(&head);
	//removing duplicate entries
	
	for(i=0;i<c;i++)
	{
		for(j=j+1;j<c;++j)
		{
			if(idle[i]==idle[j])
			{
				for(k=j;k<c;k++)
				{
					idle[k]=idle[k+1];
				}
				j--;
				c--;	

			}
		}
	}

printf("===================START=======================");
gantt_chart(head,process,idle,c);

	

}

