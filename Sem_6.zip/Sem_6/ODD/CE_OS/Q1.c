
#include<stdio.h>
#include<stdlib.h>
 typedef struct node{
	int pid;
	int p;
	float at,ft,bt,et,wt,tt;
	struct node *next;
	}Node;

Node* head = NULL;
Node* sorted = NULL;
Node* shed = NULL;
Node* shead = NULL;

void push(int pid,int p,float bt)
{
	Node* newnode = (struct node*)malloc(sizeof(struct node));
			newnode->pid=pid;
			newnode->bt=bt;
			newnode->p=p;
			newnode->at=0;
			newnode->next=head;
			head = newnode;
}
void sortedInsert(struct node* newnode)
{
	if(sorted == NULL || sorted->p > newnode->p)
		{
			newnode->next=sorted;
			sorted = newnode;
		}
		else{
			Node* current = sorted;
			if(sorted->p==newnode->p){
			  if(sorted->bt>newnode->bt){
				newnode->next = sorted;
				sorted = newnode;
				return;
	            	}
			}
			while(current->next != NULL && current-> next-> p < newnode-> p){
			current = current->next;
			 }
			newnode->next = current->next;
			current->next = newnode;
			}

}
void insertionsort()
{
	Node* current = head;
	while(current!= NULL){
	Node* next = current->next;
	sortedInsert(current);
	current = next;

	}
	head=sorted;
}
void printlist(struct node* head,int n){
	float awt=0;
	float att=0;
	printf("\n--------------------------------------\n");
	printf("\nThis is Gantt Chart\n");
	printf("\n--------------------------------------\n");
	printf("\n PID 	Prio	BT	 WT	TAT\n");
	while(head!=NULL){
		awt+=head->wt;
		att+=head->tt;
		printf("\n %d\t%d\t%0.1f\t%0.1f\t%0.1f\t",head->pid,head->p,head->bt,head->wt,head->tt);
		head = head->next;

	}
	printf("\n--------------------------------------\n");
	printf("\nAverage Waiting Time:%0.1f\t\nAverage Turnaround Time : %0.1f",awt/n,att/n);
	printf("\n---------------------------------------\n");


}
void npp(){

	float t=0;
	Node *temp = head;
	while(temp!=NULL){
		temp->et=t;
		temp->wt=t;
		t+=temp->bt;
		temp->ft=t;
		temp->tt=t;
		temp=temp->next;
		

	}
}
int main(){
	int i,n,p;
	float bt;
	printf("Number of process : ");
	scanf("%d",&n);
	for( i=0;i<n;i++)
	{
		printf("Enter priorty and burst time : ");
		scanf("%d%f",&p,&bt);
		push(i,p,bt);

	}
	insertionsort();
	npp();
	printlist(head,n);
return 0;
}
